/* 
 * File:   serial.h
 * Author: m8
 *
 * Created on 25 March 2025, 12:41
 */

#ifndef SERIAL_H
#define	SERIAL_H

void configUART(void);
void TXsend(char dato);
void TXln(void);
void TXstring(int length, char s[]);
void TXstringln(int length, char s[]);
void TXnumber(int number);
char RXserial(void);
void RXstring(int n);
int RXstringln(void);
int RXfind(char a);

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* SERIAL_H */

