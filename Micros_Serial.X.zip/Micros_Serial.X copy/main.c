/*
 * File:   main.c
 * Author: m8
 *
 * Created on 25 March 2025, 12:22
 */

#include <xc.h>
#include <stdlib.h>
#include "serial.h"

extern char buffer[32];
int comparecmd (int n,char a[]);
char cmd1[] = "R ON";
char cmd2[] = "G ON";
char cmd3[] = "B ON";
char cmd4[] = "R OFF";
char cmd5[] = "G OFF";
char cmd6[] = "B OFF";
char cmd;
// CONFIGURATION
#pragma config PLLDIV = 1
#pragma config CPUDIV = OSC1_PLL2
#pragma config USBDIV = 2
#pragma config FOSC = INTOSCIO_EC
#pragma config FCMEN = OFF
#pragma config IESO = OFF
#pragma config PWRT = OFF
#pragma config BOR = OFF
#pragma config WDT = OFF
#pragma config PBADEN = OFF
#pragma config LVP = OFF
#pragma config MCLRE = ON

#define _XTAL_FREQ 8000000
#define LEDR LATDbits.LD1
#define LEDB LATDbits.LD2
#define LEDG LATDbits.LD3
#define IN 1
#define OUT 0
#define ON 1
#define OFF 0

void main(void) {
    OSCCONbits.IRCF = 7;//Config a 8Mhz
    configUART();
    TRISD=0;
    TXstringln(8, "LED CONTROL: ");
    int n;
    while(1){
    n= RXstringln();
    cmd=0;
    int other =0;
    if(comparecmd(n,cmd1)== 1) { other = 1;}
    if(comparecmd(n,cmd2)== 1) { other = 2;}
    if(comparecmd(n,cmd3)== 1) { other = 3;}
    if(comparecmd(n,cmd4)== 1) { other = 4;}
    if(comparecmd(n,cmd5)== 1) { other = 5;}
    if(comparecmd(n,cmd6)== 1) { other = 6;}
    switch (other){
        case 1:
            LEDR = ON;
            TXstringln(6,"RED ON");
            break;
        case 2:
            LEDB = ON;
            TXstringln(6,"BLU ON");
            break;
        case 3:
            LEDG = ON;
            TXstringln(8,"GREEN ON");
            break;
        case 4:
            LEDR = OFF;
            TXstringln(7,"RED OFF");
            break;
        case 5:
            LEDB = OFF;
            TXstringln(8,"BLU OFF");
            break;
        case 6:
            LEDG = OFF;
            TXstringln(9,"GREEN OFF");
            break;
    }
    };
    return;
}

void ej1(){
    TXsend('H');
    TXsend('o');
    TXsend('l');
    TXsend('a');
    for (int i = 0; i <= 9; i++) {
        TXsend('0' + i);
        TXln();
        __delay_ms(250);
    }
    TXln();
    char msg0 [] = "Linea sin salto...";
    char msg1 [] = "Linea con salto...";
    int n = sizeof (msg0) / sizeof (char);
    TXstring(n, msg0);
    TXstring(n, msg1);
    TXstringln(8, "Numero: ");
    TXnumber(n);
}

int comparecmd(int n, char a[]){
    int eq = 1;
    for (int i=0; i<n; i++){
        if (buffer[i] == a[i]){
            eq=0;
            break;
        }
    }
    return eq;
}