//Here estan todas las funciones seriales
#include <xc.h>

char buffer[32]="                                ";

void configUART(){
    //Configura los pines
    TRISCbits.RC6 = 1; //Pin RC6 (TX) entrada
    TRISCbits.RC7 = 1; //Pin RC7 (RX) entrada
    //----Configurar UART (puerto serie) ----
    BAUDCONbits.BRG16 = 0; //Modo de 8 bits
    TXSTAbits.BRGH = 0;    //Low speed
    TXSTAbits.SYNC = 0;    //Asynchronous mode
    //Baudrate = Fosc/(64(spbrg + 1))
    //9615 = 8MHz/(64(12+1))
    SPBRG = 12; //Configurar baudrate a 9600
    BAUDCONbits.TXCKP = 0; //Polaridad NO invertida
    BAUDCONbits.RXDTP = 0;
    TXSTAbits.TX9 = 0;  //Transmisi�n de 8 bits
    RCSTAbits.RX9 = 0;
    TXSTAbits.TXEN = 1; //Habilita la transmisi�n
    RCSTAbits.CREN = 1; //Habilita la recepci�n
    RCSTAbits.SPEN = 1; //Habilita el puerto serie
    //-------------------------
}

void TXsend(char dato){
    while(TXSTAbits.TRMT == 0){
        //Espera a que el registro de 
        //transmisi�n est� disponible
    }
    TXREG = dato;
}

void TXln(){
    TXsend(10);        //Line Feed
    TXsend(13);        //CR
}

void TXstring(int length, char s[]){
    for(int i = 0; i < length; i++){
        TXsend(s[i]);
    }
}

void TXstringln(int length, char s[]){
    for(int i = 0; i < length; i++){
        TXsend(s[i]);
    }
    TXln();
}

void TXnumber(int number){
    if(number < 0){
        TXsend('-');
        number*=-1;
    }
    char U=0;
    char D=0;
    char C=0;
    char M=0;
    char DM=0;
    int temp;
    temp = number%10;
    U = (char) temp;
    temp = (number%100-U)/10;
    D = (char) temp;
    temp = (number%1000 - D*10 - U)/100;
    D = (char) temp;
    temp = (number%10000 - C*100 - D*10 - U)/1000;
    M = (char) temp;
    temp = (number%100000 - M*1000 - C*100 - D*10 - U)/10000;
    DM = (char) temp;
    if(number > 9999){
        TXsend('0'+DM);
    }
    if(number > 999){
        TXsend('0'+M);
    }
    if(number > 99){
        TXsend('0'+C);
    }
    if(number > 9){
        TXsend('0'+D);
    }
    TXsend('0'+U);
}

char RXserial(){
    char dummy;
    while(PIR1bits.RCIF == 0){}
    if(PIR1bits.RCIF == 1){
        if(RCSTAbits.FERR == 1){
            dummy = RCREG;
        }
        if(RCSTAbits.OERR == 1){
            dummy = RCREG;
            RCSTAbits.CREN = 0; //Apaga la recepci�n
            RCSTAbits.CREN = 1; //Vuelve a encender
        }
        dummy = RCREG;
        PIR1bits.RCIF = 0;  //Baja la bandera
    }
    return dummy;
}

void RXstring(int n){
    for(int i = 0; i < n; i++){
        buffer[i] = RXserial();
    }
}

int RXstringln(void){
    int i = 0;
    buffer[i] = RXserial();
    while(buffer[i] != 13 && buffer[i] != 10){
        i++;
        buffer[i] = RXserial();
    }
    return i;
}

int RXfind(char a){
    int i = 0;
    buffer[i] = RXserial();
    while(buffer[i] != a){
        i++;
        buffer[i] = RXserial();
    }
    return i; 
}